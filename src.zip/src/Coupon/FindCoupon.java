package Coupon;

import java.util.Iterator;
/*
 * create find-coupon-util class 
 */
public class FindCoupon {
	private Iostream io;//
	protected BinarySearchTree<String> my_tree;
	private SortedLinkedList sl;
	protected int count;//count linear searching times
	protected boolean found;
	/*
	 * constructor; initialize variable and read data file through IOstream
	 */
	public FindCoupon() {
		found=false;
		count=0;
		io=new Iostream();
		sl=new SortedLinkedList();
		my_tree=new BinarySearchTree<String>();
		io.autoRead();		
	}
	/*
	 * find all unused coupons from data file and return all of them
	 * use Stringbuffer to store found data 
	 * return string-type of elements
	 */
	public String find_unused() {
		StringBuffer sb=new StringBuffer();
		Iterator<Coupon> it= io.ll.iterator();//use iterator in Linkedlist to traverse every elements 
		while(it.hasNext()) {
			Coupon temp=it.next();
			if(temp.getStatus().equals("unused")) {//find out "unused" coupon and add it into stringbuffer 
				sb.append(temp+"\n");
			}
		}
		return sb.toString();
	}
	/* 
	 * find a coupon of specific product 
	 * parameter@ product name
	 * return@ String-coupon of the specific product  
	 */
	public  String find(String target) {
		Coupon return_info = null;
		Iterator<Coupon> it1= io.ll.iterator();
		while(it1.hasNext()) {
			my_tree.add(it1.next().getProduct());//build up binary search tree
		}
		found=my_tree.contains(target);//find the target in BST, if find, transfer found to true
		
		Iterator<Coupon> it2= io.ll.iterator();//use iterator in Linkedlist to traverse every elements 
		while(it2.hasNext()) {	
			count++;
			return_info=it2.next();
			if(return_info.getProduct().equals(target)) {//find the matched object and break loop
				break;
			}	
		}
		return return_info.toString();
	}
	/*
	 * find all redeemed coupon from data file 
	 */
	public String find_redeemed() {
		StringBuilder sb=new StringBuilder();
		Iterator<Coupon> it= io.ll.iterator();
		Coupon temp=null;
		while(it.hasNext()) {
			temp=it.next();
			if(temp.getStatus().equals("redeemed")) {
				sb.append(temp+"\n");
				continue;
			}
		}
		return sb.toString();
	}
	/*
	 * sort out coupon by final price in ascending order
	 */
	public String sortByfinalPrice() {
		Iterator<Coupon> it= io.ll.iterator();
		while(it.hasNext()) {
			sl.add(((it.next())));//build sortedlinkedlist
		}

		return sl.get_elements();
	}
	/*
	 * sort out coupon by provider in ascending order
	 */
	public String sortByProvider() {
		Iterator<Coupon> it= io.ll.iterator();
		while(it.hasNext()) {
			sl.addByProvider(((it.next())));//build sortedlinkedlist
		}
		return sl.get_elements();
	}
}