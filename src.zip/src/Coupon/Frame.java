package Coupon;

import java.awt.EventQueue;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

import org.omg.CORBA.INITIALIZE;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.TextField;
import java.awt.Label;
import java.awt.Font;
import java.awt.Color;


public class Frame {

	private JFrame frame;


	/**
	 * Create the application.
	 */
	public Frame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	protected void initialize() {
		setFrame(new JFrame("CouponSystem"));
		getFrame().setBounds(100, 100, 639, 444);
		getFrame().setLocation(800, 500);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getFrame().getContentPane().setLayout(null);
		
		JButton b1 = new JButton("enter");
		b1.setBackground(Color.LIGHT_GRAY);
		b1.setForeground(Color.BLACK);
		b1.setFont(new Font("SimSun", Font.PLAIN, 41));
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		b1.setBounds(186, 219, 274, 81);
		getFrame().getContentPane().add(b1);
		
		Label label = new Label("Welcome to MyCoupon System");
		label.setFont(new Font("Dialog", Font.BOLD, 33));
		label.setBounds(87, 94, 494, 69);
		getFrame().getContentPane().add(label);
		b1.addMouseListener(new MouseListener() {

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
				getFrame().setVisible(false);
				MyFrame frame = new MyFrame();
				frame.setVisible(true);
			}

		});
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
