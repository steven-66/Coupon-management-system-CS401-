package Coupon;

import java.awt.EventQueue;
import java.io.*;
import java.util.Iterator;

public class MainTest {
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame window = new Frame();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
//		System.out.println(new FindCoupon().sortByfinalPrice());
//		System.out.println(new FindCoupon().sortByProvider());
	}
}
