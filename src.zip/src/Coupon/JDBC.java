package Coupon;

import java.io.IOException;  
import java.io.InputStream;  
import java.sql.Connection;  
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement;  
import java.util.Properties;  
import java.applet.*;
import java.awt.*;
public class JDBC {  
//	public static void main(String[] args) throws ClassNotFoundException,  
//    SQLException {  
//  
//    	sb curd=new sb();  
//
//    	String sql = null;  
//    	sql="select * from coupon";  
//    	curd.Query(sql);  
//    	
//    	
//    }
  
    private static String driverName;  
    private static String url;  
    private static String user;  
    private static String password;  
  
    /* 
     * ��̬����飬���ʼ��ʱ�������ݿ����� 
     */  
    static {  
        try {  
            // ����dbinfo.properties�����ļ�  
//            InputStream in = JDBC.class.getClassLoader()  
//                    .getResourceAsStream("jdbc.properties");  
//            Properties properties = new Properties();  
//            properties.load(in);  
//  
            // ��ȡ�������ơ�url���û����Լ�����  
            driverName ="oracle.jdbc.driver.OracleDriver";
            url ="jdbc:oracle:thin:@localhost:1521:orcl";
            user ="scott";  
            password ="6666ABC822!";  
  
            // ��������  
            Class.forName(driverName);  
              
        } catch (ClassNotFoundException e) {  
            e.printStackTrace();  
        }  
    }  
  
    /* 
     * ��ȡ���� 
     */  
    public static Connection getConnection() throws SQLException {  
  
        return DriverManager.getConnection(url, user, password);  
  
    }  
  
    /* 
     * �ͷ���Դ 
     */  
    public static void releaseResources(ResultSet resultSet,  
            Statement statement, Connection connection) {  
  
        try {  
            if (resultSet != null)  
                resultSet.close();  
        } catch (SQLException e) {  
            e.printStackTrace();  
        } finally {  
            resultSet = null;  
            try {  
                if (statement != null)  
                    statement.close();  
            } catch (SQLException e) {  
                e.printStackTrace();  
            } finally {  
                statement = null;  
                try {  
                    if (connection != null)  
                        connection.close();  
                } catch (SQLException e) {  
                    e.printStackTrace();  
                } finally {  
                    connection = null;  
                }  
            }  
        }  
  
    }  
}
class sb{
    public void Query(String sql) {  
        Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {  
            connection = JDBC.getConnection();  
            statement = connection.createStatement();  
            resultSet = statement.executeQuery(sql);  
              
            while(resultSet.next()){  
                System.out.println("name:"+resultSet.getString("provider"));  
                System.out.println("id:"+resultSet.getString("order_number"));  
            }  
              
        } catch (SQLException e) {  
            e.printStackTrace();  
        } finally {  
            JDBC.releaseResources(resultSet, statement, connection);  
        }  
    }  
  
    
    
    
    
    
}
class Hello extends Applet{
	public void paint(Graphics g) {
		g.drawString("helloworld", 40, 60);
	}
}