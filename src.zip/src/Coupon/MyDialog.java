package Coupon;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SpringLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MyDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblNewLabel;


	/**
	 * Create the dialog.
	 */
	public MyDialog(String s) {
		setTitle("Tips");
		setBounds(100, 100, 673, 332);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		SpringLayout sl_contentPanel = new SpringLayout();
		contentPanel.setLayout(sl_contentPanel);
		{
			lblNewLabel = new JLabel(s);
			sl_contentPanel.putConstraint(SpringLayout.WEST, lblNewLabel, 85, SpringLayout.WEST, contentPanel);
			sl_contentPanel.putConstraint(SpringLayout.EAST, lblNewLabel, -67, SpringLayout.EAST, contentPanel);
			lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 39));
			contentPanel.add(lblNewLabel);
		}
		{
			JButton btnNewButton = new JButton("OK");
			sl_contentPanel.putConstraint(SpringLayout.SOUTH, lblNewLabel, -64, SpringLayout.NORTH, btnNewButton);
			sl_contentPanel.putConstraint(SpringLayout.EAST, btnNewButton, -28, SpringLayout.EAST, contentPanel);
			sl_contentPanel.putConstraint(SpringLayout.SOUTH, btnNewButton, -10, SpringLayout.SOUTH, contentPanel);
			btnNewButton.setFont(new Font("SimSun", Font.PLAIN, 33));
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					MyDialog.this.setVisible(false);
				}
			});
			contentPanel.add(btnNewButton);
		}
	}
}

