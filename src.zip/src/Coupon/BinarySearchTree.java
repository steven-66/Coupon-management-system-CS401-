package Coupon;


import java.util.Comparator;                                                                                                                         
import java.util.Stack;                                                                                                                              
                                                                                                                                                     
                                                                                                                                                     
/*
 * create a self-defined BST class                                                                                                                                                      
 */
public class BinarySearchTree<E>{                                                                                                                    
	protected TreeNode<E> root;// this is the absolute root of the tree                                                                                                               
	protected Comparator<E> comp;//use for comparision
	protected int count;//use for count the time of BST comparision
	/*
	 * default constructor
	 * Precondition: T implements Comparable 
	 * Creates an empty BST object - uses the natural order of elements.
	 */
	public BinarySearchTree() {                                                                                                                      
		root=null;                                                                                                                                   
		comp=new Comparator<E>() {                                                                                                                   
			public int compare(E o1, E o2) {                                                                                                         
				                                                                                                                                     
				return ((Comparable) o1).compareTo(o2);                                                                                              
			}                                                                                                                                        
		};                                                                                                                                           
	}                                                                                                                                                
	/*
	 * decide if the BST is empty, if is return true else false                                                                                                                                                 
	 */
	public boolean isEmpty(){                                                                                                                        
		return (root == null);                                                                                                                       
	} 
	/*
	 * return the number of elements in BST 
	 */
	public int size(){                                                                                                                               
		return recSize(root);                                                                                                                        
	} 
	 /* 
	  * Recursively calculates the size of the tree; 
	  * return the number of elements
	  */
	public int recSize(TreeNode<E> node) {                                                                                                           
		if(node==null) {                                                                                                                             
			return 0;                                                                                                                                
		}                                                                                                                                            
		else return 1+recSize(node.get_left())+recSize(node.get_right());                                                                            
	}                                                                                                                                                
	/*
	 * find out if the BST contains target element
	 * return true if found else false
	 */
	public boolean contains(E target) {                                                                                                              
		return recContain(target,root);                                                                                                              
	}                                                                                                                                                
     /*
      * recursively find the target 
      * return true if found else false
      */
	private boolean recContain(E target, TreeNode<E> node) {                                                                                         
                                                                                                                                                     
		if(node==null) {                                                                                                                             
			return false;                                                                                                                            
		}                                                                                                                                            
		else if(comp.compare(target, node.getInfo())<0) { 
			count++;
			return recContain(target,node.get_left());                                                                                               
		}                                                                                                                                            
		else if(comp.compare(target, node.getInfo())>0){ 
			count++;
			return recContain(target,node.get_right());                                                                                              
		}                                                                                                                                            
		else { 
			count++;
			return true;                                                                                                                             
		}                                                                                                                                            
	}                                                                                                                                                
    /*
     * iteratively add new element into BST                                                                                                                                                                                                   
     */
	public void add(E element) {                                                                                                                     
		TreeNode<E> newnode=new TreeNode<E>(element);                                                                                                
		if(root==null){                                                                                                                              
			root=newnode;                                                                                                                            
		}                                                                                                                                            
		else {                                                                                                                                       
			TreeNode<E> current=root;                                                                                                                
			while(current!=null) {                                                                                                                   
				if(comp.compare(current.getInfo(),element)<0){                                                                                       
					if(current.get_right()==null) {                                                                                                  
					current.set_right(newnode);                                                                                                      
					return;                                                                                                                          
					}                                                                                                                                
					else                                                                                                                             
						current=current.get_right();                                                                                                 
				}                                                                                                                                    
				else if(comp.compare(current.getInfo(),element)>=0) {                                                                                
					if(current.get_left()==null) {                                                                                                   
						current.set_left(newnode);                                                                                                   
						return;                                                                                                                      
					}                                                                                                                                
					else                                                                                                                             
						current=current.get_left();                                                                                                  
				}                                                                                                                                    
			}                                                                                                                                        
		}                                                                                                                                            
	}    
	/* 
	 * inorder traversal to get every element
	 */
	 public void inorder() {                                                                                                                         
		 inorder_p(root);                                                                                                                            
	}                                                                                                                                                
	 private void inorder_p(TreeNode<E> t)  {                                                                                                        
	     if(t!=null) {                                                                                                                               
	    	inorder_p(t.get_left());                                                                                                                 
	    	System.out.print(t.getInfo()+" ");                                                                                                       
	    	inorder_p(t.get_right());                                                                                                                
	     }                                                                                                                                           
	      return;                                                                                                                                    
	   }    
	 /* 
	  * preorder traversal to get every element
	  */
	 public void preorder() { preorder_p(root); }                                                                                                    
                                                                                                                                                     
	   private void preorder_p(TreeNode<E> t)  {                                                                                                     
	      if(t!=null) {                                                                                                                              
	    	  System.out.print(t.getInfo()+" ");                                                                                                     
	    	  preorder_p(t.get_left());                                                                                                              
	    	  preorder_p(t.get_right());                                                                                                             
	      }                                                                                                                                          
	      return;                                                                                                                                    
	   }
		 /* 
		  * postorder traversal to get every element
		  */
	   public void postorder() { postorder_p(root); }                                                                                                
                                                                                                                                                     
	   private void postorder_p(TreeNode<E> t)  {                                                                                                    
	     if(t!=null) {                                                                                                                               
	    	 postorder_p(t.get_left());                                                                                                              
	    	 postorder_p(t.get_right());                                                                                                             
	    	 System.out.print(t.getInfo()+" ");                                                                                                      
	     }                                                                                                                                           
	      return;                                                                                                                                    
	   }                                                                                                                                             
}    
/* Each node in the tree is an object of this type. */
class TreeNode<E>  {                                                                                                                                 
    private TreeNode<E> left,                                                                                                                        
                        right;                                                                                                                       
    private E info;                                                                                                                                  
                                                                                                                                                     
    public TreeNode(E info) {                                                                                                                        
    	left = right = null;                                                                                                                         
    	this.setInfo(info); }                                                                                                                        
    public TreeNode<E> get_left()  {                                                                                                                 
  	  return left;                                                                                                                                   
    }                                                                                                                                                
    public TreeNode<E> get_right() {                                                                                                                 
  	  return right;                                                                                                                                  
    }                                                                                                                                                
    public void set_left(TreeNode<E> left){                                                                                                          
  	  this.left=left;                                                                                                                                
    }                                                                                                                                                
    public void set_right(TreeNode<E> right){                                                                                                        
  	  this.right=right;                                                                                                                              
    }                                                                                                                                                
	public E getInfo() {                                                                                                                             
		return info;                                                                                                                                 
	}                                                                                                                                                
	public void setInfo(E info) {                                                                                                                    
		this.info = info;                                                                                                                            
	}                                                                                                                                                
 }                                                                                                                                                   