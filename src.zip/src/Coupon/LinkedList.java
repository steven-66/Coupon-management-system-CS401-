package Coupon;

import java.util.Iterator;
/*
 *create a self-defined Linkedlist collection 
 * implement LinkedListCollection<T> interface
 */
public class LinkedList<T> implements LinkedListCollection<T>{
	protected LLnode<T> previous;//this is the previous node of the current node when in traversing
	protected LLnode<T> location;//this is the current node when in traversing
	protected LLnode<T> head;//the absolute head node of linkedlist
	protected LLnode<T> tail;//the absolute tail node of linkedlist
	protected int num_elements;//number of existing elements in linkedlist
	private boolean found;
	private int size;
	private final int defsize=50;//default size of linkedlist
	/*
	 * /default constructor
	 */
	public LinkedList() {
		size=defsize;
	}
	/*
	 * construct an user-input size of linkedlist 
	 */
	public LinkedList(int size) {
		this.size=size;
	}
	/*
	 *add an new element into collection, if linkdelist is full then return false else return true
	 *@param T 
	 *@return boolean 
	*/
	public boolean add(T element) {
		if(is_full()) {
			return false;
		}
		else{
			LLnode<T> newnode=new LLnode<T>(element);
			if(head==null) {
				newnode.setLink(head);
				head=newnode;
				tail=newnode;
			}
			else{
				newnode.setLink(head);
				head=newnode;
			}
			num_elements++;
			return true;
		}
	}
	/*
	 * find the target element in collection if successful, return true else return false
	 * @param T
	 * @return boolean
	 */
	public boolean find(T target) {
		int count =1;
		location=head;
		boolean found=false;
		while(location!=null) {
			if(location.getInfo().equals(target)) {
				found=true;
				break;
			}
			else {
				count++;
				previous=location;
				location=location.getLink();
			}
		}
		return found;
	}
	/*
	 *remove the target element in collection, first find it if failed return false
	 *else remove it in linkedlist and return true
	 *@param T
	 *@return boolean
	 */
	public boolean remove(T target) {
		find(target);
		if(head==location) {
			head=head.getLink();
			num_elements--;
		}
		else {
			previous.setLink(location.getLink());
			num_elements--;
		}
		return found;
	}
	/*
	 * return false if the linkedlist is out of size else return true
	 */
	public boolean is_full() {
		return (num_elements==size);
	}
	/*
	 * traverse the linkedlist and get every element in each node
	 * @return String 
	 */
	public String get_elements() {
		LLnode<T> get = head;
		StringBuffer s=new StringBuffer();//use a StringBuffer to load every element temporarily
		while(get!=null) {
			s.append(get.getInfo()+"\n");
			get=get.getLink();
		}
		return s.toString();
	}
	/*
	 * define a inner class that implements Iterator<T> interface 
	 * which is use as an iterator
	 */
	private class LinkedListIterator implements Iterator<T>{
		LLnode<T> next;
	 public LinkedListIterator() {
			next=head;
		}
	@Override
		public boolean hasNext() {
		
			return next!=null;
		}
	@Override
		public T next() {
			T info=next.getInfo();
			next=next.getLink();
			return info;
		}
	}
	/*
	 * create a new self-defined iterator object
	 */
	public Iterator<T> iterator(){
		return new LinkedListIterator();
	}

}
/*
 * each node of linkedlist is an object like this 
 */
class LLnode<T>{
	private LLnode<T> link;
	private T info;
	public LLnode(T info) {
		link=null;
		this.info=info;
	}
	public LLnode<T> getLink() {
		return link;
	}
	public void setLink(LLnode<T> link) {
		this.link = link;
	}
	public T getInfo() {
		return info;
	}
	public void setInfo(T info) {
		this.info = info;
	}
	
}