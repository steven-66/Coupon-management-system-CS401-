package Coupon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/*
 * create an util class that can read or write data into data-file using IO
 */

public class Iostream {
	private BufferedReader br;
	private File f;
	private FileWriter fw;
	private BufferedWriter bw;
	protected LinkedList<Coupon> ll;
	/*
	 * constructor:create default-size linkedlist and create a new File object to access to the data-file
	 */
	public Iostream(){
		f=new File("src\\Coupon\\1.txt");
		ll=new LinkedList<Coupon>();
	}
	/*
	 * input user-defined size of linkedlist container; 
	 */
	public void ll_construct(int i) {
		ll=new LinkedList<Coupon>(i);
	}
	/*
	 * read data-file and export data into linkedlist;
	 */
	public void autoRead() {
		try {
			String line=null;
			br=new BufferedReader(new FileReader(f));//create new buffer to store data temporarily 
			while((line=br.readLine())!=null){
				String[] s=line.split(" ");
				Coupon c=new Coupon(s[0],s[1],Integer.parseInt(s[2].replace("$","")),Integer.parseInt(s[3].replace("%", "")),Integer.parseInt(s[4].replace("d","")),s[5]);
				ll.add(c);
			}
		}
		catch(IOException e) {
			System.out.println(e.toString());
		}
		finally {
			try {
				if(br!=null) {
					br.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/*
	 * write a coupon object into data-file
	 * @param Coupon 
	 */
	public  void write_file(Coupon c) {
		ll.add(c);
		try {
			fw=new FileWriter(f, true);
			bw=new BufferedWriter(fw);
			bw.write(c.toString());
			bw.newLine();
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try{
				if(bw!=null) {
				bw.close();
				}
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
}
