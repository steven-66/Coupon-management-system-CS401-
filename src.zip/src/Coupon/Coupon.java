package Coupon;
/*
 * Coupon class; the main class of this project 
 */
public class Coupon implements Comparable<Coupon> {
	private String provider;
	private String product;
	private int prod_price;
	private int discount_rate;
	private int expiration;
	private String status;
	/*
	 * constructor: create a object with specific attributes
	 */
	public Coupon(String provider, String product, int prod_price, int discount_rate, int expiration, String status) {
		this.provider=provider;
		this.product=product;
		this.prod_price=prod_price;
		this.discount_rate=discount_rate;
		this.expiration=expiration;
		this.status=status;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public int getProd_price() {
		return prod_price;
	}
	public void setProd_price(int prod_price) {
		this.prod_price = prod_price;
	}
	public int getDiscount_rate() {
		return discount_rate;
	}
	public void setDiscount_rate(int discount_rate) {
		this.discount_rate = discount_rate;
	}
	public int getExpiration() {
		return expiration;
	}
	public void setExpiration(int expiration) {
		this.expiration = expiration;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	/*
	 * make comparasion by final price
	 */
	@Override
	public int compareTo(Coupon arg) {
		
		return (this.prod_price*(100-this.discount_rate))-(arg.prod_price*(100-arg.discount_rate));
	}
	/*
	 * make comparasion by provider name
	 */
	public int compareTo_provider(Coupon arg) {
		return this.provider.compareTo(arg.provider);
		
	}
	@Override
	public String toString() {
		return provider + " "+product +" "+ prod_price+"$ "+ discount_rate + "% " +expiration+ "d "+ status;
	}
}
