package Coupon;
/*
 * create interface which is implemented by linkdelist
 */
public interface LinkedListCollection<T> {
	 boolean find(T target);
	 public boolean remove(T target);
	 public boolean is_full();
	 public boolean add(T element);
}
