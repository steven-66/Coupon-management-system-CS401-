package Coupon;
/*
 * create a sorted linkedlist class that extends linkedlist
 * infer generic Coupon
 */
public class SortedLinkedList extends LinkedList<Coupon> {
	protected LLnode<Coupon> next;
	/*
	 * add a Coupon object by ascending order if success return true else return false
	 * when adding a new element compare
	 * @param Coupon
	 * @return boolean
	 */
	public boolean add(Coupon target) {
		if(head==null) { 
			super.add(target);
		}
		else {										
			if(target.compareTo(head.getInfo())<=0) {		//compare with head node if smaller than it then become head
				super.add(target);
				return true;
			}
			else if(target.compareTo(tail.getInfo())>0) {       //compare with tail node if bigger than it then become tail
				LLnode<Coupon> newnode= new LLnode<Coupon>(target);
				tail.setLink(newnode);
				tail=newnode;
				num_elements++;
				return true;
			}
			else if(target.compareTo(head.getInfo())>0) {  //if bigger than head taverse next node until find one node
					location=head;							// that is bigger than target and insert target
					while(location!=null) {
						previous=location;
						location=location.getLink();
						if(target.compareTo(location.getInfo())>0) {
							continue;
						}
						else if(target.compareTo(location.getInfo())<=0){
							LLnode<Coupon> newnode=new LLnode<Coupon>(target);
							previous.setLink(newnode);
							newnode.setLink(location);
							num_elements++;
							return true;
						}		
					}
				}
			}
		return true;
	}
	/*
	 * add Coupon by provider name in ascending order
	 * similar to the add method
	 */
	public void addByProvider(Coupon target) {
		if(head==null) {
			super.add(target);
		}
		else {
			if(target.compareTo_provider(head.getInfo())<=0) {
				super.add(target);
				return;
			}
			if(target.compareTo_provider(tail.getInfo())>0) {
				LLnode<Coupon> newnode= new LLnode<Coupon>(target);
				tail.setLink(newnode);
				tail=newnode;
				num_elements++;
				return;
			}
			location=head;
			if(target.compareTo_provider(head.getInfo())>0) {
				while(location!=null) {
					previous=location;
					location=location.getLink();
					if(target.compareTo_provider(location.getInfo())>0){	
						continue;
					}
					else if(target.compareTo_provider(location.getInfo())<=0){
							LLnode<Coupon> newnode=new LLnode<Coupon>(target);
							previous.setLink(newnode);
							newnode.setLink(location);
							num_elements++;
							return;
					}		
				}
			}
		}
	}
}
