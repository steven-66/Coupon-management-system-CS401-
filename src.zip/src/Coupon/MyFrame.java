package Coupon;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.TextArea;
import java.awt.Window;
import java.io.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.TabableView;
import javax.swing.text.AbstractDocument.BranchElement;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.SwingConstants;
import javax.swing.JScrollBar;
import javax.swing.JToolBar;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SpringLayout;
import java.awt.Window.Type;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JCheckBox;

public class MyFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private FindCoupon fc=new FindCoupon();
	/**
	 * Create the frame.
	 */
	public MyFrame() {
		setType(Type.NORMAL);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,1600, 900);
		setLocation(700, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane jp= new JTabbedPane(JTabbedPane.LEFT);
		jp.setFont(new Font("SimSun", Font.PLAIN, 35));
		 JPanel p1=new JPanel() ;    
		   JPanel p2=new JPanel() ;
		   JPanel p3=new JPanel() ;
		   JPanel p4=new JPanel() ;
		   JPanel p5 = new JPanel();
		   JPanel p6 = new JPanel();
		   JPanel p7 = new JPanel();
		   this.getContentPane().add(jp,BorderLayout.CENTER);   //add this tabbedpane  into main frame
			jp.setBounds(0, 0, 1600, 1000);
			contentPane.add(jp);
			contentPane.setVisible(true);
		 
		   /*
		    * add new sub-container into tab and name them
		    */
		
		   jp.add("My Coupon", p1)  ;
		   jp.add("Search Coupon", p2)  ;
		   jp.add("Sort Coupon", p3)  ;
		   jp.add("Add Coupon", p4)  ;  
		   jp.add("Unused Coupon", p5);
		   jp.add("Redeemded Coupon", p6);
		   jp.add("ListByProvider", p7);
		   p1.setLayout(null);
		   SpringLayout sl_p2 = new SpringLayout();
		   p2.setLayout(sl_p2);
		   p3.setLayout(null);
		   SpringLayout sl_p4 =new SpringLayout();
		   p4.setLayout(sl_p4);
		   p5.setLayout(null);
		   p6.setLayout(null);
		   p7.setLayout(null);
		   /*
		    * add a new textarea into p1 panel and list existing coupons of user from data file.
		    */
		   TextArea t1=new TextArea();
		   t1.setBounds(0, 0, 1200, 800);
		   t1.setFont(new Font("Dialog", Font.PLAIN, 37));
		   t1.setCaretPosition(600);
		   p1.add(t1);
		   read_file(t1);
		 
		   /*
		    * set the layout of p2 panel and add components
		    */
		   textField = new JTextField();
		   sl_p2.putConstraint(SpringLayout.NORTH, textField, 6, SpringLayout.NORTH, p2);
		   sl_p2.putConstraint(SpringLayout.WEST, textField, 20, SpringLayout.WEST, p2);
		   sl_p2.putConstraint(SpringLayout.EAST, textField, 372, SpringLayout.WEST, p2);
		   p2.add(textField);
		   textField.setColumns(10);
		   textField.setFont(new Font("SimSun", Font.PLAIN, 36));
		   TextArea ar= new TextArea("",20,20,TextArea.SCROLLBARS_BOTH );
		   sl_p2.putConstraint(SpringLayout.NORTH, ar, 11, SpringLayout.SOUTH, textField);
		   sl_p2.putConstraint(SpringLayout.WEST, ar, 10, SpringLayout.WEST, p2);
		   sl_p2.putConstraint(SpringLayout.SOUTH, ar, -66, SpringLayout.SOUTH, p2);
		   sl_p2.putConstraint(SpringLayout.EAST, ar, -50, SpringLayout.EAST, p2);
		   ar.setFont(new Font("SimSun", Font.PLAIN, 32)); 
		   ar.setBounds(0, 0, 1200, 800);
		   p2.add(ar);
		   /*
		    * add button into p2 and perform to search specific coupon in data file 
		    */
		   JButton b1 = new JButton("Search");
		   b1.setFont(new Font("SimSun", Font.PLAIN, 26));
		   sl_p2.putConstraint(SpringLayout.NORTH, b1, 6, SpringLayout.NORTH, textField);
		   sl_p2.putConstraint(SpringLayout.WEST, b1, 30, SpringLayout.EAST, textField);
		   b1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
		   		String temp=fc.find(textField.getText());
		   		if(fc.found==true) {
		   			ar.setText(temp+"\n"+"Found in "+fc.my_tree.count+"th by BST search and "+fc.count+"th by linear search");}
		   		else if(fc.found==false) {
		   			ar.setText("No Coupon is found - "+fc.my_tree.count+"th by BST search and "+fc.count+"th by linear search");}
		   	}
		   });
		   p2.add(b1);
		   /*
		    * sort coupon by final price
		    */
		   TextArea t2=new TextArea();
		   t2.setBounds(0, 0, 1200, 800);
		   t2.setFont(new Font("Dialog", Font.PLAIN, 37));
		   t2.setCaretPosition(600);
		   p3.add(t2);
		   t2.setText(new FindCoupon().sortByfinalPrice());
		   /*
		    * sort coupon by provider
		    */
		   TextArea t5=new TextArea();
		   t5.setBounds(0, 0, 1200, 800);
		   t5.setFont(new Font("Dialog", Font.PLAIN, 37));
		   t5.setCaretPosition(600);
		   p7.add(t5);
		   t5.setText(fc.sortByProvider());
		   /*
		    * find all unused coupon
		    */
		   TextArea t3=new TextArea();
		   t3.setBounds(0, 0, 1200, 800);
		   t3.setFont(new Font("Dialog", Font.PLAIN, 37));
		   t3.setCaretPosition(600);
		   p5.add(t3);
		   t3.setText(fc.find_unused());
		   /*
		    * find all redeemed coupon
		    */
		   TextArea t4=new TextArea();
		   t4.setBounds(0, 0,1200, 800);
		   t4.setFont(new Font("Dialog", Font.PLAIN, 37));
		   t4.setCaretPosition(600);
		   p6.add(t4);
	
		   t4.setText(fc.find_redeemed());
		    /*
		     * add components into p4 panel and set layout
		     */
		   JLabel lblProvider = new JLabel("provider"); 
		   sl_p4.putConstraint(SpringLayout.NORTH, lblProvider, 55, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, lblProvider, 0, SpringLayout.WEST, p4);
		   lblProvider.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(lblProvider);
		   
		   JTextField provider = new JTextField();//for input "provider" 
		   provider.setFont(new Font("SimSun", Font.PLAIN, 34));
		   sl_p4.putConstraint(SpringLayout.NORTH, provider, 58, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, provider, 239, SpringLayout.WEST, p4);
		   sl_p4.putConstraint(SpringLayout.EAST, provider, 626, SpringLayout.WEST, p4);
		   p4.add(provider);
		   provider.setColumns(10);
		   
		   JLabel lblProduct = new JLabel("product");
		   sl_p4.putConstraint(SpringLayout.NORTH, lblProduct, 102, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, lblProduct, 0, SpringLayout.WEST, p4);
		   lblProduct.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(lblProduct);
		   
		   JTextField product = new JTextField();//for input "product" 
		   product.setFont(new Font("SimSun", Font.PLAIN, 34));
		   sl_p4.putConstraint(SpringLayout.NORTH, product, 105, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, product, 239, SpringLayout.WEST, p4);
		   sl_p4.putConstraint(SpringLayout.EAST, product, 626, SpringLayout.WEST, p4);
		   p4.add(product);
		   product.setColumns(10);
		   
		   JLabel lblWx = new JLabel("product price");
		   sl_p4.putConstraint(SpringLayout.NORTH, lblWx, 149, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, lblWx, 0, SpringLayout.WEST, p4);
		   lblWx.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(lblWx);
		   
		   JTextField pro_price = new JTextField();// for input "product price" 
		   pro_price.setFont(new Font("SimSun", Font.PLAIN, 34));
		   sl_p4.putConstraint(SpringLayout.NORTH, pro_price, 152, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, pro_price, 239, SpringLayout.WEST, p4);
		   sl_p4.putConstraint(SpringLayout.EAST, pro_price, 626, SpringLayout.WEST, p4);
		   p4.add(pro_price);
		   pro_price.setColumns(10);
		   
		   JLabel lblDiscountRate = new JLabel("discount rate");
		   sl_p4.putConstraint(SpringLayout.NORTH, lblDiscountRate, 196, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, lblDiscountRate, 0, SpringLayout.WEST, p4);
		   lblDiscountRate.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(lblDiscountRate);
		   
		   JTextField dis_rate = new JTextField();// for input "discount rate" 
		   dis_rate.setFont(new Font("SimSun", Font.PLAIN, 34));
		   sl_p4.putConstraint(SpringLayout.NORTH, dis_rate, 199, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, dis_rate, 239, SpringLayout.WEST, p4);
		   sl_p4.putConstraint(SpringLayout.EAST, dis_rate, 626, SpringLayout.WEST, p4);
		   p4.add(dis_rate);
		   dis_rate.setColumns(10);
		   
		   JLabel lblExpiration = new JLabel("expiration");
		   sl_p4.putConstraint(SpringLayout.NORTH, lblExpiration, 243, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, lblExpiration, 0, SpringLayout.WEST, p4);
		   lblExpiration.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(lblExpiration);
		   JTextField exp = new JTextField();// for input "expiration" 
		   exp.setFont(new Font("SimSun", Font.PLAIN, 34));
		   sl_p4.putConstraint(SpringLayout.NORTH, exp, 246, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, exp, 239, SpringLayout.WEST, p4);
		   sl_p4.putConstraint(SpringLayout.EAST, exp, 626, SpringLayout.WEST, p4);
		   exp.setColumns(10);
		   p4.add(exp);
		   /*
		    * select status of adding coupon
		    */
		   JLabel lblStatus = new JLabel("status");
		   sl_p4.putConstraint(SpringLayout.NORTH, lblStatus, 294, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, lblStatus, 0, SpringLayout.WEST, p4);
		   lblStatus.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(lblStatus);
		   
		   JCheckBox c2 = new JCheckBox("unused");
		   sl_p4.putConstraint(SpringLayout.NORTH, c2, -4, SpringLayout.NORTH, lblStatus);
		   sl_p4.putConstraint(SpringLayout.WEST, c2, 0, SpringLayout.WEST, provider);
		   c2.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(c2);
		   
		   JCheckBox c1 = new JCheckBox("redeemed");
		   sl_p4.putConstraint(SpringLayout.NORTH, c1, -4, SpringLayout.NORTH, lblStatus);
		   sl_p4.putConstraint(SpringLayout.EAST, c1, 0, SpringLayout.EAST, provider);
		   c1.setFont(new Font("SimSun", Font.PLAIN, 36));
		   p4.add(c1);
		   
		   /*
		    * type in coupon info and add new coupon into data file;when add completed a dialog will show result.
		    */
		   JButton btnNewButton_1 = new JButton("submit");
		   sl_p4.putConstraint(SpringLayout.NORTH, btnNewButton_1, 397, SpringLayout.NORTH, p4);
		   sl_p4.putConstraint(SpringLayout.WEST, btnNewButton_1, 380, SpringLayout.WEST, p4);
		   btnNewButton_1.addActionListener(new ActionListener() {
			   	public void actionPerformed(ActionEvent e) {
			   		
			   		MyDialog dialog=new MyDialog("Coupon Added Sucessfully");
			   		dialog.setVisible(true);
			   		dialog.setLocation(800, 500);
			   		read_file(t1);
			   	}
			   });
		   /*
		    * transfer input value into Coupon object and put it into data file;
		    */
		   btnNewButton_1.addActionListener(new ActionListener() {
		   	public void actionPerformed(ActionEvent e) {
		   		String pr=provider.getText();
		   		String pt=product.getText();
		   		int price=Integer.parseInt(pro_price.getText());
		   		int discount=Integer.parseInt(dis_rate.getText());
		   		int expiration=Integer.parseInt(exp.getText());
		   		String sta=null;
		   		if(c1.isSelected()) {
		   			sta=c1.getText();
		   		}
		   		else if(c2.isSelected()) {
		   			sta=c2.getText();
		   		}
		   		Coupon coupon=new Coupon(pr, pt, price, discount, expiration, sta);
		   		new Iostream().write_file(coupon);
		   		t5.setText(new FindCoupon().sortByProvider());
		   		t2.setText(new FindCoupon().sortByfinalPrice());
		   		
		   		if(c1.isSelected()) {
		   			t4.append(coupon.toString());
		   		}
		   		else if(c2.isSelected()) {
		   			t3.append(coupon.toString());
		   		}
		   	}
		   });
		   p4.add(btnNewButton_1);		
	
	   	
	}
	/*
	 * read data from data-file and show the result in textarea
	 */
	  public  void read_file(TextArea t) {
		   BufferedReader br = null;
		   try {
			  br= new BufferedReader(new FileReader("src\\Coupon\\1.txt"));
			  String line;
			  while((line=br.readLine())!=null){
				   t.append(line+"\n");
			  }
		   } 
		   catch (Exception e) {
			   e.printStackTrace();
		   	}
		   finally {
			   try {
				   if(br!=null) {
					   br.close();
				   }
			   }
			   catch (Exception e) {
				   e.printStackTrace();
			   	}
		   }
	   }
}